#include "test_env.h"

int main() {
    GREENTEA_SETUP(15, "default_auto");
    GREENTEA_TESTSUITE_RESULT(true);
}